/* empty css              */import{c as r}from"./VAvatar-BBI11nYU.js";const s=r("v-spacer","div","VSpacer");export{s as V};
